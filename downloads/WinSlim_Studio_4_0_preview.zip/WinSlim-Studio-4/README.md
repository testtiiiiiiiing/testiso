# WinSlim Studio 4.0

App desktop in italiano per personalizzare **ISO ufficiali Windows 10/11 x64**.
Ricostruita dal programma WinSlim Studio 3.1 allegato dall'utente: il motore di
base è stato riscritto in Python leggibile e l'interfaccia recuperata è stata
adattata. Il runtime non richiede pacchetti Python aggiuntivi.

## Avvio su Windows

L'eseguibile di anteprima è in `dist/WinSlim_Studio_4_0_preview.exe`.
Non richiede Python installato. Il programma richiede l'elevazione tramite UAC.
Per creare ISO occorre installare **Windows ADK → Deployment Tools**, che include
`oscdimg.exe`; si può indicarne il percorso nella pagina Sorgente.

Per avviare dai sorgenti, installare Python 3.13 x64 con Tcl/Tk e il launcher `py`,
quindi fare doppio clic su `run_windows.cmd`, oppure:

```powershell
cd C:\percorso\WinSlim-Studio
py -3.13 -m winslim
```

Scegli una ISO, premi **Leggi edizioni**, seleziona le edizioni, configura le
modifiche e controlla il **Riepilogo** prima di creare la nuova ISO. Tutte le
rimozioni sono disattivate inizialmente. Le modifiche riguardano la copia offline
dell'immagine, non il Windows attualmente in uso.

Usa una cartella di lavoro dedicata con almeno 20 GB liberi; per ISO grandi la
stima richiesta aumenta a quattro volte la dimensione della sorgente. È richiesto
anche spazio per l'uscita. Sono supportati percorsi con spazi. Sorgenti e uscita
devono stare fuori dalla sottocartella `WinSlim_work`. Se questa esiste già,
il programma la conserva e chiede di scegliere un'altra cartella di lavoro.

## Funzioni

- Lettura e selezione delle edizioni WIM/ESD, ISO avviabile BIOS/UEFI.
- Rimozione di app provisionate e componenti, catalogo in sola lettura.
- Driver INF firmati, anche in boot.wim; aggiornamenti CAB/MSU ordinabili.
- Installer EXE/MSI e piano energetico al primo accesso amministratore.
- Servizi offline con controllo di servizi essenziali, driver e dipendenze.
- Registro offline, file aggiuntivi, personalizzazione del profilo Default.
- Installazione automatica: lingua, account, accesso automatico e partizionamento
  esplicito del disco di destinazione. La password è scritta nel file
  `autounattend.xml` della ISO; viene esclusa da configurazioni JSON e report.
- Configurazioni JSON compatibili con schema 2, riepilogo e confronto prima/dopo.
- Annullamento fra comandi; DISM attivo viene lasciato terminare prima di scartare
  le immagini montate dalla lavorazione.

Le aggiunte principali sono il profilo **Privacy**, **Ripristina scelte / Ctrl+Z**
per annullare l'ultimo profilo o importazione (fino a 10), SHA-256 della sorgente
e dell'uscita, diagnostica Windows e validazione più rigorosa delle configurazioni.

La nuova ISO sostituisce l'uscita solo dopo che `oscdimg` e il calcolo SHA-256
sono terminati. Un errore o annullamento precedente conserva l'uscita esistente.
Le edizioni importate da un JSON devono essere rilette dalla ISO reale.
I percorsi che coincidono con sorgenti, anche tramite hard link, vengono respinti.
I file REG vengono indirizzati esclusivamente agli hive offline; il ControlSet
attivo viene rilevato dal registro dell'immagine.

**Defender viene preservato:** la rimozione fisica presente nell'originale è stata
esclusa perché non verificabile in modo affidabile fra build. I vecchi JSON che
la richiedono devono disattivare `variables.v_defender` prima di creare.

## Test eseguiti e limiti

Sono passati **44 test** con Python 3.12 e 3.13 su Linux, con display virtuale
reale per Tk. Coprono le otto pagine, importazione, profili, annullamento,
protezione dei percorsi, registro, XML, output atomico, hash, dipendenze dei
driver e un flusso completo multi-edizione con risposte Windows simulate.

**L'EXE e la creazione/avvio/installazione di ISO reali non sono stati eseguiti
su Windows.** Il pacchetto è una versione di anteprima, non una release
certificata. I test simulati non dimostrano la compatibilità di DISM, driver,
aggiornamenti o impostazioni con una particolare build di Windows. Non è
possibile garantire l'assenza assoluta di bug.

L'EXE di anteprima riutilizza bootloader e runtime Windows Python/Tcl del file
allegato, sostituendo interamente il codice applicativo con questi sorgenti.
`dist/WinSlim_Studio_4_0_preview.manifest.json` registra provenienza, hash e
stato del collaudo. Per un EXE con runtime nuovo, indipendente dall'allegato,
esegui `build_windows.cmd`: testa i sorgenti e compila con PyInstaller 6.16.0.
La workflow `.github/workflows/windows.yml` prepara lo stesso EXE su Windows
quando il repository viene pubblicato; non è stata avviata in questa sessione.

Prima di usare una ISO per installazioni reali occorre creare una ISO da una
sorgente nota, verificarne SHA-256, avviarla in una VM UEFI e verificare Setup,
primo accesso, app, servizi, driver e Windows Update. I bypass Windows 11 e
alcuni criteri dipendono dalla build. ISO ARM64/x86 e immagini SWM divise non
sono supportate.

## Test e sviluppo

```powershell
$env:WINSLIM_REQUIRE_GUI = '1'
py -3.13 -m unittest discover -s tests -v
```

Su Linux, con un display disponibile:

```bash
DISPLAY=:99 WINSLIM_REQUIRE_GUI=1 python3 -m unittest discover -s tests -v
DISPLAY=:99 python3 -m winslim
```

Senza display, i test GUI vengono segnalati come saltati. Imposta
`WINSLIM_REQUIRE_GUI=1` per considerarli obbligatori. L'interfaccia può essere
controllata su Linux; le operazioni Windows non vengono emulate dal programma.

`winslim/base.py` contiene il motore e i comandi Windows, `winslim/safety.py` la
validazione indipendente dalla piattaforma e `winslim/studio.py` l'interfaccia
e le integrazioni. `tools/export_test_scripts.py` esporta gli script PowerShell
per controllarli con il parser Windows senza eseguire modifiche.

## Recupero di una lavorazione interrotta

Conserva il log e la cartella di lavoro riportata dall'errore. Dal terminale
amministratore, `dism /Get-MountedImageInfo` elenca le immagini ancora montate.
Controlla che il MountDir sia proprio il `mount` o `bootmount` della tua
lavorazione prima di scartarlo con:

```powershell
dism /Unmount-Image /MountDir:"C:\tua-cartella\WinSlim_work\mount" /Discard
```

Se il log riporta un hive ancora caricato, scarica solo quello della lavorazione
indicata, per esempio `reg unload HKLM\WS_SYSTEM`. Le istanze di WinSlim usano
un mutex Windows per evitare lavorazioni contemporanee sugli stessi nomi hive.
Non eseguire una pulizia globale delle immagini DISM. Elimina la cartella della
lavorazione solo dopo aver verificato lo smontaggio; non contiene la ISO originale.
